import {
  CardsStackBack,
  CardsStackFront,
  CardsStackItem,
  CardsStackNext,
  CardsStackPrevious,
  CardsStackRoot,
  CardsStackStatus,
  CardsStackViewport,
} from "../components/CardsStackSlider";

const cards = [
  { id: "aurora", title: "Aurora", details: "Northern lights over the coast." },
  { id: "forest", title: "Forest", details: "A quiet trail through old pines." },
  { id: "ocean", title: "Ocean", details: "Evening waves beneath a clear sky." },
] as const;

export default function CardsStackSliderExample() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-100 p-6">
      <CardsStackRoot count={cards.length} aria-label="Featured destinations">
        <CardsStackViewport>
          {cards.map((card, index) => (
            <CardsStackItem
              key={card.id}
              index={index}
              aria-label={`${card.title}: ${card.details}`}
            >
              <CardsStackFront className="grid place-items-center bg-slate-950 p-8 text-white">
                <h2 className="text-3xl font-semibold">{card.title}</h2>
              </CardsStackFront>
              <CardsStackBack className="grid place-items-center bg-indigo-700 p-8 text-white">
                <p>{card.details}</p>
              </CardsStackBack>
            </CardsStackItem>
          ))}
        </CardsStackViewport>
        <div className="flex items-center gap-4">
          <CardsStackPrevious className="border border-slate-300 bg-white px-4">Previous</CardsStackPrevious>
          <CardsStackStatus className="min-w-14 text-center" />
          <CardsStackNext className="border border-slate-300 bg-white px-4">Next</CardsStackNext>
        </div>
      </CardsStackRoot>
    </main>
  );
}
