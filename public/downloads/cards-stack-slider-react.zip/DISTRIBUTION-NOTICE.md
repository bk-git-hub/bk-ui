# Distribution notice

Component: Cards Stack Slider
Pinned source: fecaf6502f823c379eedfbeb3e1b3e256040ff5e
License status: UNLICENSED / pending project-owner decision.

No redistribution license or public-release permission is granted by this generated notice. Do not present this verification artifact as a published BK-UI release.
