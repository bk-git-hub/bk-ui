# Cards Stack Slider for React/Vite

> Release blocked: BK-UI does not yet declare redistribution license terms. This archive is a deterministic local verification artifact, not a published release.

Pinned source commit: `fecaf6502f823c379eedfbeb3e1b3e256040ff5e`
Entry point after copying: `components/CardsStackSlider/index.ts`

Copy the `components/` directory into a Tailwind-scanned local source directory, then choose exactly one supported Tailwind dependency set below.

### Tailwind 3

- Supported range: `>=3.4.0 <4` (tested `3.4.19`)
- Install: `clsx@^2.1.1 tailwind-merge@2.6.0`
- Source discovery: Add "./components/**/*.{js,ts,jsx,tsx}" to tailwind.config content after copying the component.

### Tailwind 4

- Supported range: `>=4.0.0 <5` (tested `4.3.2`)
- Install: `clsx@^2.1.1 tailwind-merge@^3.3.1`
- Source discovery: Keep components/CardsStackSlider under a locally scanned source tree; otherwise add a stylesheet-relative @source directive for that directory.

## SSR and hydration constraints

- Browser APIs are accessed only from effects or pointer and transition event handlers; do not invoke interaction handlers during server render.
- Keep onValueChange, DOM event handlers, and function-valued CardsStackStatus children inside the Next.js Client Component boundary; pass only serializable card data from Server Components.
- Render output is deterministic for the same count, initial value, card order, orientation, and options and does not require ssr: false.
- Use the same count, card order, orientation, and initial value for the server render and first hydration render.

## Accessibility constraints

- Give CardsStackRoot a localized accessible label that identifies the carousel.
- Keep CardsStackViewport keyboard-focusable and preserve its visible focus ring and orientation-aware Arrow key navigation.
- Keep inactive cards aria-hidden and inert so assistive technology and keyboard users interact only with the active card.
- Preserve CardsStackPrevious and CardsStackNext as native-button alternatives to pointer dragging.
- Preserve motion-reduce transition handling and add data-cards-stack-no-drag to interactive descendants that must not initiate a drag.

The React entry uses the same canonical core bytes as the Next.js archive.

See `manifest.json` for exact file SHA-256 values and `examples/` for integration code.
