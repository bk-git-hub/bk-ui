import ShaderSliderClient, {
  type ShaderSliderStory,
} from "./client-wrapper";

const stories = [
  {
    src: "/images/tidal-glass.webp",
    alt: "Teal glass waves beneath a warm sun",
    title: "Tidal Glass",
  },
  {
    src: "/images/electric-bloom.webp",
    alt: "Luminous magenta petals over a violet sky",
    title: "Electric Bloom",
  },
] satisfies readonly ShaderSliderStory[];

export default function Page() {
  return (
    <main className="mx-auto max-w-5xl p-6">
      <ShaderSliderClient stories={stories} />
    </main>
  );
}
