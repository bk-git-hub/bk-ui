"use client";

import { useEffect, useState } from "react";
import {
  ShaderSliderNext,
  ShaderSliderPagination,
  ShaderSliderPrevious,
  ShaderSliderRoot,
  ShaderSliderSlide,
  ShaderSliderStatus,
  ShaderSliderViewport,
  type ShaderSliderImage,
} from "../components/ShaderSlider/client";

export interface ShaderSliderStory extends ShaderSliderImage {
  title: string;
}

export interface ShaderSliderClientProps {
  stories: readonly ShaderSliderStory[];
}

export default function ShaderSliderClient({
  stories,
}: ShaderSliderClientProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  if (!mounted) {
    return (
      <div
        aria-hidden="true"
        className="aspect-video w-full rounded-3xl bg-slate-950"
      />
    );
  }

  return (
    <ShaderSliderRoot
      slides={stories}
      effect="wave"
      transitionDuration={950}
      intensity={0.9}
      frequency={2.75}
      dprCap={2}
      loop
      aria-label="Visual stories"
      className="relative overflow-hidden rounded-3xl bg-slate-950 text-white"
    >
      <ShaderSliderViewport className="aspect-video">
        {stories.map((story, index) => (
          <ShaderSliderSlide
            key={story.src}
            index={index}
            className="flex items-end bg-gradient-to-t from-black/80 to-transparent p-8 pb-20"
          >
            <h2 className="text-4xl font-black">{story.title}</h2>
          </ShaderSliderSlide>
        ))}
      </ShaderSliderViewport>
      <ShaderSliderPrevious className="absolute left-4 top-1/2 z-30 -translate-y-1/2 bg-black/55 px-4 py-3">
        Previous
      </ShaderSliderPrevious>
      <ShaderSliderNext className="absolute right-4 top-1/2 z-30 -translate-y-1/2 bg-black/55 px-4 py-3">
        Next
      </ShaderSliderNext>
      <ShaderSliderPagination
        aria-label="Choose a visual story"
        className="absolute bottom-6 left-8 z-30 [&>button]:h-6 [&>button]:min-w-6"
      />
      <ShaderSliderStatus className="absolute bottom-6 right-8 z-30" />
    </ShaderSliderRoot>
  );
}
