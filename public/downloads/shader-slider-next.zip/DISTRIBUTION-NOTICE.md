# Distribution notice

Component: Shader Slider
Pinned source: 9abab5bafae37adc13716b6072b6280c8b82f4f4
License status: UNLICENSED / pending project-owner decision.

No redistribution license or public-release permission is granted by this generated notice. Do not present this verification artifact as a published BK-UI release.
