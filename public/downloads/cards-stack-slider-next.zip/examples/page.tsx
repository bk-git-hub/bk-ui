import {
  CardsStackGallery,
  type SerializableCard,
} from "./client-wrapper";

const cards: readonly SerializableCard[] = [
  { id: "aurora", title: "Aurora", details: "Northern lights over the coast." },
  { id: "forest", title: "Forest", details: "A quiet trail through old pines." },
  { id: "ocean", title: "Ocean", details: "Evening waves beneath a clear sky." },
];

export default function Page() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-100 p-6">
      <CardsStackGallery cards={cards} />
    </main>
  );
}
