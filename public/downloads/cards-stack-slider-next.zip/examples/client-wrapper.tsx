"use client";

import { useState } from "react";
import {
  CardsStackBack,
  CardsStackFront,
  CardsStackItem,
  CardsStackNext,
  CardsStackPrevious,
  CardsStackRoot,
  CardsStackStatus,
  CardsStackViewport,
} from "../components/CardsStackSlider/client";

export interface SerializableCard {
  id: string;
  title: string;
  details: string;
}

export interface CardsStackGalleryProps {
  cards: readonly SerializableCard[];
}

export function CardsStackGallery({ cards }: CardsStackGalleryProps) {
  const [value, setValue] = useState(0);

  return (
    <CardsStackRoot
      count={cards.length}
      value={value}
      onValueChange={(nextValue) => setValue(nextValue)}
      aria-label="Featured destinations"
    >
      <CardsStackViewport>
        {cards.map((card, index) => (
          <CardsStackItem
            key={card.id}
            index={index}
            aria-label={`${card.title}: ${card.details}`}
          >
            <CardsStackFront className="grid place-items-center bg-slate-950 p-8 text-white">
              <h2 className="text-3xl font-semibold">{card.title}</h2>
            </CardsStackFront>
            <CardsStackBack className="grid place-items-center bg-indigo-700 p-8 text-white">
              <p>{card.details}</p>
            </CardsStackBack>
          </CardsStackItem>
        ))}
      </CardsStackViewport>
      <div className="flex items-center gap-4">
        <CardsStackPrevious className="border border-slate-300 bg-white px-4">Previous</CardsStackPrevious>
        <CardsStackStatus className="min-w-14 text-center" />
        <CardsStackNext className="border border-slate-300 bg-white px-4">Next</CardsStackNext>
      </div>
    </CardsStackRoot>
  );
}
