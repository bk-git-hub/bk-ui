import {
  TinderCard,
  TinderEmptyFallback,
  TinderLikeButton,
  TinderNopeButton,
  TinderResetButton,
  TinderRoot,
} from "../components/Tinder";

interface Profile {
  id: string;
  name: string;
  age: number;
}

const profiles: readonly Profile[] = [
  { id: "ada", name: "Ada", age: 29 },
  { id: "grace", name: "Grace", age: 31 },
];

export default function TinderExample() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-100 p-6">
      <TinderRoot cards={profiles}>
        {({ currentIndex, visibleCards }) => (
          <section aria-label="Profile deck">
            <div className="relative h-[28rem] w-80">
              {visibleCards.map(({ item, index }) => (
                <TinderCard
                  key={item.id}
                  index={index}
                  role="group"
                  aria-label={`${item.name}, age ${item.age}`}
                  aria-hidden={index !== currentIndex}
                  className="grid place-items-center p-8"
                >
                  <h2 className="text-2xl font-semibold">{item.name}</h2>
                  <p>Age {item.age}</p>
                </TinderCard>
              ))}
              <TinderEmptyFallback className="absolute inset-0 grid place-items-center">
                <div role="status" aria-live="polite" className="text-center">
                  <p>All profiles reviewed.</p>
                  <TinderResetButton type="button">Review again</TinderResetButton>
                </div>
              </TinderEmptyFallback>
            </div>
            <div className="mt-6 flex justify-center gap-4">
              <TinderNopeButton type="button" aria-label="Pass profile" className="rounded-full bg-white px-5 py-3 focus-visible:outline-2">
                Pass
              </TinderNopeButton>
              <TinderLikeButton type="button" aria-label="Like profile" className="rounded-full bg-white px-5 py-3 focus-visible:outline-2">
                Like
              </TinderLikeButton>
            </div>
          </section>
        )}
      </TinderRoot>
    </main>
  );
}
