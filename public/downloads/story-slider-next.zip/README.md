# Story Slider for Next.js App Router

> Release blocked: BK-UI does not yet declare redistribution license terms. This archive is a deterministic local verification artifact, not a published release.

Pinned source commit: `25febb424babdbbe6b4dc0a16e32ff7a347790b5`
Entry point after copying: `components/StorySlider/client.ts`

Copy the `components/` directory into a Tailwind-scanned local source directory, then choose exactly one supported Tailwind dependency set below.

### Tailwind 3

- Supported range: `>=3.4.0 <4.0.0` (tested `3.4.17`)
- Install: `clsx@^2.1.1 tailwind-merge@2.6.0`
- Source discovery: Add './src/components/StorySlider/**/*.{js,ts,jsx,tsx}' (or the equivalent installed path) to the content array in tailwind.config.js or tailwind.config.ts.

### Tailwind 4

- Supported range: `>=4.0.0 <5.0.0` (tested `4.3.2`)
- Install: `clsx@^2.1.1 tailwind-merge@^3.3.1`
- Source discovery: Keep components/StorySlider under a locally scanned source tree; otherwise add a stylesheet-relative @source directive for that directory.

## SSR and hydration constraints

- Import the Next.js entrypoint from components/StorySlider/client; it is the only Next-only file and re-exports the unchanged React core without next/* imports.
- Keep callbacks, refs, DOM event handlers, function-valued duration, and StorySliderItem, StorySliderPlayback, or StorySliderStatus render-function children inside a Client Component; pass only serializable data from a Server Component.
- Keep groupCounts, value or defaultValue, ordered groups, and rendered story content deterministic between the server render and the first hydration render.
- Reduced-motion and document-visibility effects may pause playback after hydration without changing the deterministic first render.
- The core does not read window or document during render; matchMedia, document visibility, animation frames, performance timing, and pointer APIs are accessed only after hydration in effects or interaction handlers, so ssr: false is not required.

## Accessibility constraints

- Do not remove the inactive group and item inert and aria-hidden behavior or the StorySliderStatus live region.
- Keep StorySliderViewport keyboard-focusable so ArrowLeft, ArrowRight, Home, End, and Space navigation and visible focus styles remain available.
- Preserve the prefers-reduced-motion auto-pause behavior and motion-reduce transition utilities when extending styles.
- Provide StorySliderPlayback whenever autoplay is enabled so users can pause or resume stories, and keep previous and next controls as native buttons with descriptive labels.
- Provide a meaningful accessible name for StorySliderRoot through aria-label or aria-labelledby and meaningful text or image alternative text for every story.

Keep callbacks, render functions, and other non-serializable props inside the included Client Component wrapper. Pass only serializable data from Server Components.

See `manifest.json` for exact file SHA-256 values and `examples/` for integration code.
