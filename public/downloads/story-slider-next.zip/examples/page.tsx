import StorySliderClient, {
  type SerializableStoryGroup,
} from "./client-wrapper";

const groups = [
  {
    id: "city",
    label: "City",
    stories: [
      { id: "dawn", title: "First light", tone: "amber" },
      { id: "night", title: "Neon walk", tone: "violet" },
    ],
  },
  {
    id: "coast",
    label: "Coast",
    stories: [{ id: "tide", title: "Low tide", tone: "sky" }],
  },
] satisfies readonly SerializableStoryGroup[];

export default function Page() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-950 p-6">
      <StorySliderClient groups={groups} />
    </main>
  );
}
