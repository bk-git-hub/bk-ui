"use client";

import {
  ShutterSliderNext,
  ShutterSliderPagination,
  ShutterSliderPrevious,
  ShutterSliderRoot,
  ShutterSliderSlide,
  ShutterSliderStatus,
  ShutterSliderViewport,
  type ShutterSliderImage,
} from "../components/ShutterSlider/client";

export interface ShutterSliderClientProps {
  stories: readonly { image: ShutterSliderImage; title: string }[];
}

export default function ShutterSliderClient({
  stories,
}: ShutterSliderClientProps) {
  return (
    <ShutterSliderRoot
      slides={stories.map((story) => story.image)}
      stripCount={5}
      transitionDuration={820}
      stagger={52}
      aria-label="Travel stories"
      className="overflow-hidden rounded-3xl bg-slate-950 text-white"
    >
      <ShutterSliderViewport className="aspect-video">
        {stories.map((story, index) => (
          <ShutterSliderSlide
            key={story.image.src}
            index={index}
            className="flex items-end p-8 pb-20"
          >
            <h2 className="text-4xl font-black">{story.title}</h2>
          </ShutterSliderSlide>
        ))}
      </ShutterSliderViewport>
      <ShutterSliderPrevious className="absolute left-4 top-1/2 z-30">
        Previous
      </ShutterSliderPrevious>
      <ShutterSliderNext className="absolute right-4 top-1/2 z-30">
        Next
      </ShutterSliderNext>
      <ShutterSliderPagination
        aria-label="Choose a travel story"
        className="absolute bottom-6 left-8 z-30"
      />
      <ShutterSliderStatus className="absolute bottom-6 right-8 z-30" />
    </ShutterSliderRoot>
  );
}
