import ShutterSliderClient from "./client-wrapper";

const stories = [
  {
    image: { src: "/images/river.webp", alt: "A river at sunset" },
    title: "Blue hour",
  },
  {
    image: { src: "/images/alley.webp", alt: "A rain-lit alley" },
    title: "After the rain",
  },
  {
    image: { src: "/images/platform.webp", alt: "A platform beside the sea" },
    title: "Last train",
  },
] as const;

export default function Page() {
  return (
    <main className="mx-auto max-w-5xl p-6">
      <ShutterSliderClient stories={stories} />
    </main>
  );
}
