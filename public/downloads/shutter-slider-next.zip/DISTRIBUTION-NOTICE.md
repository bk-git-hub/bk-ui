# Distribution notice

Component: Shutter Slider
Pinned source: a4f7c1cdec909c9e09b2d18a3006c43f484f54f9
License status: UNLICENSED / pending project-owner decision.

No redistribution license or public-release permission is granted by this generated notice. Do not present this verification artifact as a published BK-UI release.
