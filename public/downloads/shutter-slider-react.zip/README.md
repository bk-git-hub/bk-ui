# Shutter Slider for React/Vite

> Release blocked: BK-UI does not yet declare redistribution license terms. This archive is a deterministic local verification artifact, not a published release.

Pinned source commit: `a4f7c1cdec909c9e09b2d18a3006c43f484f54f9`
Entry point after copying: `components/ShutterSlider/index.ts`

Copy the `components/` directory into a Tailwind-scanned local source directory, then choose exactly one supported Tailwind dependency set below.

### Tailwind 3

- Supported range: `>=3.4.0 <4.0.0` (tested `3.4.17`)
- Install: `clsx@^2.1.1 tailwind-merge@2.6.0`
- Source discovery: Add './components/ShutterSlider/**/*.{ts,tsx}' (or the equivalent installed path) to the content array in tailwind.config.js or tailwind.config.ts.

### Tailwind 4

- Supported range: `>=4.0.0 <4.2.0` (tested `4.1.10`)
- Install: `clsx@^2.1.1 tailwind-merge@^3.3.1`
- Source discovery: Files copied under the app source tree are detected automatically; for an external or ignored location, add a stylesheet-relative @source directive for './components/ShutterSlider' to the global Tailwind stylesheet.

## SSR and hydration constraints

- Do not require ssr: false: matchMedia, animation frames, and timers are read only after hydration in effects, event handlers, or cleanup.
- Import the Next.js entrypoint from components/ShutterSlider/client; it is the only Next-only file and re-exports the unchanged React core without next/* imports.
- Keep callbacks, refs, DOM event handlers, ShutterSliderPagination getLabel, and ShutterSliderStatus render-function children inside a Client Component; pass only serializable data from a Server Component.
- Keep slides, defaultValue, and rendered children deterministic between the server render and initial hydration.

## Accessibility constraints

- Do not remove the inactive slide inert and aria-hidden behavior or the polite ShutterSliderStatus live region.
- Give custom previous, next, and pagination controls descriptive accessible labels while preserving native button semantics.
- Keep ShutterSliderViewport keyboard-focusable so ArrowLeft, ArrowRight, Home, and End navigation remains available.
- Preserve the prefers-reduced-motion behavior and motion-reduce utilities when extending transition styles.
- Provide a meaningful alt string for every slide image and an accessible name for the ShutterSliderRoot.

The React entry uses the same canonical core bytes as the Next.js archive.

See `manifest.json` for exact file SHA-256 values and `examples/` for integration code.
