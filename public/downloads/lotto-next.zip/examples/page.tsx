import { LottoMachineClient } from "./client-wrapper";

const balls = Array.from({ length: 45 }, (_, index) => index + 1);

export default function Page() {
  return (
    <main className="mx-auto max-w-4xl p-6">
      <LottoMachineClient balls={balls} drawCount={6} />
    </main>
  );
}
