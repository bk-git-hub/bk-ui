"use client";

import { useEffect, useRef, useState } from "react";
import { LottoAction, LottoMachine, useLottoDraw } from "../components/Lotto/client";

export interface LottoMachineClientProps {
  balls: readonly number[];
  drawCount: number;
}

export function LottoMachineClient({ balls, drawCount }: LottoMachineClientProps) {
  const [result, setResult] = useState<number[]>([]);
  const [spinning, setSpinning] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { canDraw, draw, reset } = useLottoDraw({
    items: balls,
    drawCount,
    value: result,
    onValueChange: setResult,
  });

  useEffect(() => () => {
    if (timerRef.current !== null) clearTimeout(timerRef.current);
  }, []);

  const startDraw = () => {
    if (!canDraw || spinning) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      draw();
      return;
    }
    setSpinning(true);
    timerRef.current = setTimeout(() => {
      draw();
      setSpinning(false);
      timerRef.current = null;
    }, 4_800);
  };

  return (
    <section className="mx-auto max-w-3xl space-y-6">
      <LottoMachine
        items={balls}
        drawnItems={spinning ? [] : result}
        spinning={spinning}
        resultCount={drawCount}
        motionSeed={2026}
        getItemKey={(ball) => ball}
        aria-label="Weekly lotto machine"
      />
      <div className="flex justify-center gap-3">
        <LottoAction disabled={!canDraw || spinning} onClick={startDraw}>
          {spinning ? "Mixing..." : "Draw"}
        </LottoAction>
        <LottoAction disabled={spinning || result.length === 0} onClick={reset}>
          Reset
        </LottoAction>
      </div>
    </section>
  );
}
