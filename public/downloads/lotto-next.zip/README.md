# Lotto Draw for Next.js App Router

> Release blocked: BK-UI does not yet declare redistribution license terms. This archive is a deterministic local verification artifact, not a published release.

Pinned source commit: `8cb1677b64f5934db933c15a602ae45741c5bbd3`
Entry point after copying: `components/Lotto/client.ts`

Copy the `components/` directory into a Tailwind-scanned local source directory, then choose exactly one supported Tailwind dependency set below.

### Tailwind 4

- Supported range: `>=4.0.0 <5` (tested `4.3.2`)
- Install: `lucide-react@^0.542.0 tailwind-merge@^3.3.1`
- Source discovery: Keep components/Lotto in the locally scanned source tree; for shared or ignored source add a stylesheet-relative @source directive for that directory.

## SSR and hydration constraints

- Browser measurement, ResizeObserver, matchMedia, and animation frames run only after hydration; Lotto does not require ssr: false.
- Define onValueChange, renderBall, getItemKey, getItemLabel, random, timers, refs, and DOM handlers inside a Client Component; pass only serializable data from a Server Component.
- Import the Next.js entrypoint from components/Lotto/client; it re-exports the unchanged React core and contains no next/* runtime import.
- Keep items, initial results, motionSeed, drawCount, and labels deterministic between the server render and the first hydration render.
- Random selection begins only when draw is called from an interaction and is never consumed during render.

## Accessibility constraints

- For object items, provide stable getItemKey and meaningful getItemLabel functions inside the client boundary.
- Give LottoDraw or LottoMachine a meaningful accessible name and preserve the polite result status announcement.
- Keep LottoAction as a native button with visible focus styles, disabled behavior, and keyboard activation; do not make drawing pointer-only.
- Keep the decorative chamber pool aria-hidden while exposing the result list and machine state through semantic regions and lists.
- Preserve prefers-reduced-motion handling so the result appears without the mixing delay and the chamber remains static.

Keep callbacks, render functions, and other non-serializable props inside the included Client Component wrapper. Pass only serializable data from Server Components.

See `manifest.json` for exact file SHA-256 values and `examples/` for integration code.
