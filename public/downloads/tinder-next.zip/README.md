# Tinder Swiper for Next.js App Router

> Release blocked: BK-UI does not yet declare redistribution license terms. This archive is a deterministic local verification artifact, not a published release.

Pinned source commit: `35d17dd9e1c04f4f35d9cf72f2c2574ebfceff0c`
Entry point after copying: `components/Tinder/client.ts`

Copy the `components/` directory into a Tailwind-scanned local source directory, then choose exactly one supported Tailwind dependency set below.

### Tailwind 3

- Supported range: `>=3.4.0 <4` (tested `3.4.17`)
- Install: `clsx@^2.1.1 tailwind-merge@2.6.0`
- Source discovery: Add "./src/components/Tinder/**/*.{js,ts,jsx,tsx}" (or the copied equivalent) to tailwind.config content.

### Tailwind 4

- Supported range: `>=4.0.0 <5` (tested `4.3.2`)
- Install: `clsx@^2.1.1 tailwind-merge@^3.3.1`
- Source discovery: Keep components/Tinder in the locally scanned source tree; for shared source add a stylesheet-relative @source directive for that directory.

## SSR and hydration constraints

- Browser globals, requestAnimationFrame, and element mutation are used only by effects or interaction handlers; do not invoke those handlers during server render.
- Keep render-prop children and callback props inside the Next.js Client Component boundary, and pass only serializable cards and deckKey from Server Components.
- Render output is deterministic for the same ordered cards and does not require ssr: false.
- Use the same ordered cards and stable deckKey for the server render and first hydration render.

## Accessibility constraints

- Keep the native Like, Nope, Undo, and Reset button semantics, provide meaningful accessible names, and preserve visible focus styles.
- Mark non-current stacked cards aria-hidden so assistive technology reads only the active card.
- Pointer dragging has button-based keyboard equivalents; do not remove those controls.
- Provide visible profile text and appropriate image alternative text; use an empty alt only when an image duplicates that text.
- The current core does not disable its imperative swipe animation for prefers-reduced-motion; adapt the locally copied source when strict reduced-motion support is required.

Keep callbacks, render functions, and other non-serializable props inside the included Client Component wrapper. Pass only serializable data from Server Components.

See `manifest.json` for exact file SHA-256 values and `examples/` for integration code.
