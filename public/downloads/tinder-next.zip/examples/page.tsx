import { TinderDeck, type SerializableProfile } from "./client-wrapper";

const cards: readonly SerializableProfile[] = [
  { id: "ada", name: "Ada", age: 29 },
  { id: "grace", name: "Grace", age: 31 },
];

export default function Page() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-100 p-6">
      <TinderDeck
        cards={cards}
        deckKey={cards.map((card) => card.id).join(":")}
      />
    </main>
  );
}
