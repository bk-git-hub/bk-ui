"use client";

import {
  TinderCard,
  TinderEmptyFallback,
  TinderLikeButton,
  TinderNopeButton,
  TinderResetButton,
  TinderRoot,
} from "../components/Tinder/client";

export interface SerializableProfile {
  id: string;
  name: string;
  age: number;
}

export interface TinderDeckProps {
  cards: readonly SerializableProfile[];
  deckKey: string;
}

export function TinderDeck({ cards, deckKey }: TinderDeckProps) {
  return (
    <TinderRoot key={deckKey} cards={cards}>
      {({ currentIndex, visibleCards }) => (
        <section aria-label="Profile deck">
          <div className="relative h-[28rem] w-80">
            {visibleCards.map(({ item, index }) => (
              <TinderCard
                key={item.id}
                index={index}
                role="group"
                aria-label={`${item.name}, age ${item.age}`}
                aria-hidden={index !== currentIndex}
                className="grid place-items-center p-8"
              >
                <h2 className="text-2xl font-semibold">{item.name}</h2>
                <p>Age {item.age}</p>
              </TinderCard>
            ))}
            <TinderEmptyFallback className="absolute inset-0 grid place-items-center">
              <div role="status" aria-live="polite" className="text-center">
                <p>All profiles reviewed.</p>
                <TinderResetButton type="button">Review again</TinderResetButton>
              </div>
            </TinderEmptyFallback>
          </div>
          <div className="mt-6 flex justify-center gap-4">
            <TinderNopeButton type="button" aria-label="Pass profile" className="rounded-full bg-white px-5 py-3 focus-visible:outline-2">
              Pass
            </TinderNopeButton>
            <TinderLikeButton type="button" aria-label="Like profile" className="rounded-full bg-white px-5 py-3 focus-visible:outline-2">
              Like
            </TinderLikeButton>
          </div>
        </section>
      )}
    </TinderRoot>
  );
}
