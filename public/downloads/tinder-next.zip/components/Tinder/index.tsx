import React, { createContext, useContext, useMemo } from "react";
import { useTinderSwipe } from "./useTinderSwipe";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";

type TinderSwipeContextType = ReturnType<typeof useTinderSwipe> | null;

const TinderSwipeContext = createContext<TinderSwipeContextType>(null);

const useTinderContext = () => {
  const context = useContext(TinderSwipeContext);
  if (!context) {
    throw new Error(
      "Tinder.* components must be rendered within a Tinder.Root component.",
    );
  }

  return context;
};

const VISIBLE_CARD_COUNT = 3;

export interface TinderVisibleCard<T> {
  item: T;
  index: number;
}

export interface TinderRootRenderProps<T> {
  currentIndex: number;
  visibleCards: readonly TinderVisibleCard<T>[];
}

export interface TinderRootProps<T> {
  cards: readonly T[];
  children:
    | React.ReactNode
    | ((state: TinderRootRenderProps<T>) => React.ReactNode);
  onSwipeLeft?: (item: T) => void;
  onSwipeRight?: (item: T) => void;
}

export const TinderRoot = <T,>({
  cards,
  children,
  onSwipeLeft,
  onSwipeRight,
}: TinderRootProps<T>) => {
  const swipeApi = useTinderSwipe({
    itemCount: cards.length,
    onSwipeLeft: (index) => {
      if (cards[index]) onSwipeLeft?.(cards[index]);
    },
    onSwipeRight: (index) => {
      if (cards[index]) onSwipeRight?.(cards[index]);
    },
  });

  const visibleCards = useMemo(
    () =>
      cards
        .slice(
          swipeApi.currentIndex,
          swipeApi.currentIndex + VISIBLE_CARD_COUNT,
        )
        .map((item, offset) => ({
          item,
          index: swipeApi.currentIndex + offset,
        })),
    [cards, swipeApi.currentIndex],
  );

  const content =
    typeof children === "function"
      ? children({ currentIndex: swipeApi.currentIndex, visibleCards })
      : children;

  return (
    <TinderSwipeContext.Provider value={swipeApi}>
      {content}
    </TinderSwipeContext.Provider>
  );
};
interface TinderCardProps extends React.HTMLAttributes<HTMLDivElement> {
  index: number;
  children: React.ReactNode;
}

export const TinderCard = ({
  index,
  children,
  className,
  style,
  ...props
}: TinderCardProps) => {
  const {
    currentIndex,
    itemCount,
    topCardRef,
    nextCardRef,
    handlePointerDown,
    likeIndicatorRef,
    nopeIndicatorRef,
  } = useTinderContext();

  if (index < currentIndex || index > currentIndex + 2) return null;

  const isTopCard = index === currentIndex;
  const isNextCard = index === currentIndex + 1;

  return (
    <div
      ref={isTopCard ? topCardRef : isNextCard ? nextCardRef : null}
      onPointerDown={isTopCard ? handlePointerDown : undefined}
      className={twMerge(
        clsx(
          "absolute h-full w-full cursor-grab [touch-action:none] overflow-hidden rounded-xl bg-white shadow-lg transition-transform duration-300 ease-out select-none",
          (isTopCard || isNextCard) && "will-change-transform",
          className,
        ),
      )}
      style={{
        zIndex: itemCount - index,
        transform: isTopCard
          ? "none"
          : `scale(${1 - (index - currentIndex) * 0.1}) translate3d(0, ${(index - currentIndex) * 12}px, 0)`,
        ...style,
      }}
      {...props}
    >
      {children}
      {isTopCard && (
        <>
          <div
            ref={likeIndicatorRef}
            className="pointer-events-none absolute top-10 left-10 -rotate-12 transform rounded-xl border-4 border-green-500 p-2 text-4xl font-bold text-green-500 opacity-0"
          >
            LIKE
          </div>
          <div
            ref={nopeIndicatorRef}
            className="pointer-events-none absolute top-10 right-10 rotate-12 transform rounded-xl border-4 border-red-500 p-2 text-4xl font-bold text-red-500 opacity-0"
          >
            NOPE
          </div>
        </>
      )}
    </div>
  );
};

export const TinderNopeButton = (
  props: React.ButtonHTMLAttributes<HTMLButtonElement>,
) => {
  const { animateSwipe, isFinished } = useTinderContext();
  if (isFinished) return null;
  return <button onClick={() => animateSwipe("left")} {...props} />;
};

export const TinderLikeButton = (
  props: React.ButtonHTMLAttributes<HTMLButtonElement>,
) => {
  const { animateSwipe, isFinished } = useTinderContext();
  if (isFinished) return null;
  return <button onClick={() => animateSwipe("right")} {...props} />;
};

export const TinderEmptyFallback = ({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) => {
  const { isFinished } = useTinderContext();

  return isFinished ? <div className={className}>{children}</div> : null;
};

export const TinderUndoButton = ({
  children,
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) => {
  const { undo, currentIndex } = useTinderContext();
  const isDisabled = currentIndex === 0;
  return (
    <button
      onClick={undo}
      disabled={isDisabled}
      className={twMerge("...", className)}
      {...props}
    >
      {children}
    </button>
  );
};

export const TinderResetButton = ({
  children,
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement>) => {
  const { reset, currentIndex } = useTinderContext();
  const isDisabled = currentIndex === 0;
  return (
    <button
      onClick={reset}
      disabled={isDisabled}
      className={twMerge("...", className)}
      {...props}
    >
      {children}
    </button>
  );
};
