# Distribution notice

Component: Story Slider
Pinned source: 25febb424babdbbe6b4dc0a16e32ff7a347790b5
License status: UNLICENSED / pending project-owner decision.

No redistribution license or public-release permission is granted by this generated notice. Do not present this verification artifact as a published BK-UI release.
