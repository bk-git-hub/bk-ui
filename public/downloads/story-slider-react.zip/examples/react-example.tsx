import {
  StorySliderGroup,
  StorySliderItem,
  StorySliderNext,
  StorySliderPlayback,
  StorySliderPrevious,
  StorySliderProgress,
  StorySliderRoot,
  StorySliderStatus,
  StorySliderViewport,
} from "../components/StorySlider";

const groups = [
  {
    id: "city",
    label: "City",
    stories: [
      { id: "dawn", title: "First light", className: "bg-amber-600" },
      { id: "night", title: "Neon walk", className: "bg-violet-700" },
    ],
  },
  {
    id: "coast",
    label: "Coast",
    stories: [
      { id: "tide", title: "Low tide", className: "bg-sky-700" },
    ],
  },
] as const;

export default function StorySliderExample() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-950 p-6 text-white">
      <StorySliderRoot
        groupCounts={groups.map((group) => group.stories.length)}
        duration={4500}
        loop
        aria-label="Travel stories"
        className="w-full max-w-sm"
      >
        <StorySliderViewport className="rounded-3xl bg-slate-900 shadow-2xl">
          {groups.map((group, groupIndex) => (
            <StorySliderGroup
              key={group.id}
              index={groupIndex}
              aria-label={group.label + " stories"}
              className="rounded-3xl"
            >
              {group.stories.map((story, itemIndex) => (
                <StorySliderItem
                  key={story.id}
                  index={itemIndex}
                  className={"flex items-end rounded-3xl p-8 " + story.className}
                >
                  <h2 className="text-4xl font-black">{story.title}</h2>
                </StorySliderItem>
              ))}
            </StorySliderGroup>
          ))}
          <StorySliderProgress className="absolute inset-x-0 top-0 z-30 m-4 w-auto" />
          <StorySliderPlayback className="absolute right-4 top-8 z-40 bg-black/55 px-3 text-sm">
            {({ paused }) => (paused ? "Play" : "Pause")}
          </StorySliderPlayback>
        </StorySliderViewport>
        <div className="mt-4 flex items-center justify-between gap-3">
          <StorySliderPrevious className="bg-white/10 px-4">Previous</StorySliderPrevious>
          <StorySliderStatus className="text-white/75" />
          <StorySliderNext className="bg-white/10 px-4">Next</StorySliderNext>
        </div>
      </StorySliderRoot>
    </main>
  );
}
