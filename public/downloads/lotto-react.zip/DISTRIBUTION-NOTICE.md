# Distribution notice

Component: Lotto Draw
Pinned source: 8cb1677b64f5934db933c15a602ae45741c5bbd3
License status: UNLICENSED / pending project-owner decision.

No redistribution license or public-release permission is granted by this generated notice. Do not present this verification artifact as a published BK-UI release.
