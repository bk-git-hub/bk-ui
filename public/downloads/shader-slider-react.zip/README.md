# Shader Slider for React/Vite

> Release blocked: BK-UI does not yet declare redistribution license terms. This archive is a deterministic local verification artifact, not a published release.

Pinned source commit: `9abab5bafae37adc13716b6072b6280c8b82f4f4`
Entry point after copying: `components/ShaderSlider/index.ts`

Copy the `components/` directory into a Tailwind-scanned local source directory, then choose exactly one supported Tailwind dependency set below.

### Tailwind 3

- Supported range: `>=3.4 <4` (tested `3.4.19`)
- Install: `clsx@^2.1.1 tailwind-merge@2.6.0`
- Source discovery: Include the installed directory in Tailwind content, for example './src/components/ShaderSlider/**/*.{js,ts,jsx,tsx}' or './components/ShaderSlider/**/*.{js,ts,jsx,tsx}'.

### Tailwind 4

- Supported range: `>=4 <5` (tested `4.3.2`)
- Install: `clsx@^2.1.1 tailwind-merge@^3.3.1`
- Source discovery: Keep components/ShaderSlider under a locally scanned source tree; otherwise add a stylesheet-relative @source directive for that directory.

## SSR and hydration constraints

- Do not require ssr: false; the mounted placeholder is deterministic and browser rendering begins after hydration.
- Import the Next.js entrypoint from components/ShaderSlider/client; it is the only Next-only file and re-exports the unchanged React core without next/* imports.
- Keep onValueChange, children, refs, and DOM event handlers inside a Client Component; pass only the declared serializable data and primitive options from a Server Component.
- The mounted Next.js wrapper server-renders a placeholder instead of slide content; provide a separate static image when no-JavaScript image content is required.
- Use same-origin texture URLs or CORS headers compatible with each slide crossOrigin value; failed WebGL texture loading falls back to the accessible DOM images.
- Use the included mount-gated Client Component wrapper so the server markup and first hydration markup match before the core reads matchMedia and initializes WebGL or ResizeObserver.

## Accessibility constraints

- Do not remove the inactive slide inert and aria-hidden behavior, the aria-hidden canvas, or the polite ShaderSliderStatus live region.
- Increase pagination button hit areas in product styling when the target-size policy exceeds the default 0.5rem visual dots.
- Keep ShaderSliderViewport keyboard-focusable so ArrowLeft, ArrowRight, Home, and End navigation and visible focus styles remain available.
- Preserve prefers-reduced-motion behavior and motion-reduce utilities when extending transition styles.
- Provide a meaningful non-empty alt string for every slide and an accessible name through aria-label or aria-labelledby on ShaderSliderRoot.
- Use semantic interactive elements or data-shader-slider-no-drag for custom slide controls so pointer gestures do not intercept their interaction.

The React entry uses the same canonical core bytes as the Next.js archive.

See `manifest.json` for exact file SHA-256 values and `examples/` for integration code.
